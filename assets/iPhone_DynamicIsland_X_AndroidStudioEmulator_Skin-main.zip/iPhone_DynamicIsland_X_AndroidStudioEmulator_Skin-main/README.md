# iPhone 14 Pro Max Dynamic Island Notch and X Notch Android Studio Emulator Skin File
*Hello!*  👋

I designed skins for android developers who don't have a macbook.  (like me 😥)

Brings the themes of iPhone X device for Android Studio Emulator.

*Other IOS devices will be added later.*

# how do i use it?
* Download iPhone X folder.

- The files you downloaded  C:\Users\User\AppData\Local\Android\Sdk\skins\ move it in the folder.

- Create a new virtual device in AVD Manager.

- In **Virtual Device Configuration**, click **New Hardware Profile** to create a profile for your new virtual device.

- Fill in the specification of your virtual device. Resolution (912x1974px, 5,8 inch).

- In the **Default Skin**, select the downloaded Emulator Skin.

- Verify all configuration and check if the Emulator Skin is applied by clicking **Show Advanced Settings**.

- Launch the newly created virtual device in the **AVD Manager**.

- Done.

> [!INFO] > You can do original scaling in the layout file. > Images may be corrupted!

![Engelbart](https://i.ibb.co/ckPTk4W/i-Phone-AVD-Readme.png)
